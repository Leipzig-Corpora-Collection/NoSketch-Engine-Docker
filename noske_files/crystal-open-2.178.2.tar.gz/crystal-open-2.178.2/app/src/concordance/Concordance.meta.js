const Meta = {
    options:{
        // type=object -> option is stringified before sending to url query
        criteria:{
            type: "object"
        }
    }
}

module.exports = Meta




